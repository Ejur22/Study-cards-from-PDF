import React, { useState } from 'react'
import UploadScreen from './components/UploadScreen'
import QuizScreen from './components/QuizScreen'
import ResultsScreen from './components/ResultsScreen'
import { sampleQuestions } from './data/sampleQuestions'

function App() {
  const [currentScreen, setCurrentScreen] = useState('upload')
  const [uploadedFile, setUploadedFile] = useState(null)
  const [quizResults, setQuizResults] = useState(null)

  const handleFileUpload = (file) => {
    setUploadedFile(file)
  }

  const handleStartTest = () => {
    setCurrentScreen('quiz')
  }

  const handleQuizComplete = (results) => {
    setQuizResults(results)
    setCurrentScreen('results')
  }

  const handleRestart = () => {
    setCurrentScreen('upload')
    setUploadedFile(null)
    setQuizResults(null)
  }

  return (
    <div className="app-container">
      {currentScreen === 'upload' && (
        <UploadScreen
          onFileUpload={handleFileUpload}
          onStartTest={handleStartTest}
          uploadedFile={uploadedFile}
        />
      )}
      
      {currentScreen === 'quiz' && (
        <QuizScreen
          questions={sampleQuestions}
          onComplete={handleQuizComplete}
          onBack={() => setCurrentScreen('upload')}
        />
      )}
      
      {currentScreen === 'results' && (
        <ResultsScreen
          results={quizResults}
          onRestart={handleRestart}
        />
      )}
    </div>
  )
}

export default App
