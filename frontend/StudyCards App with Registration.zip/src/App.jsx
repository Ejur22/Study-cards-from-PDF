import React, { useState } from 'react'
import Header from './components/Header'
import MainScreen from './components/MainScreen'
import RegistrationScreen from './components/RegistrationScreen'
import './App.css'

function App() {
  const [currentScreen, setCurrentScreen] = useState('main')

  const handleAvatarClick = () => {
    setCurrentScreen(currentScreen === 'main' ? 'registration' : 'main')
  }

  return (
    <div className="app">
      <Header onAvatarClick={handleAvatarClick} />
      <main className="main-content">
        {currentScreen === 'main' ? (
          <MainScreen />
        ) : (
          <RegistrationScreen onBack={() => setCurrentScreen('main')} />
        )}
      </main>
    </div>
  )
}

export default App
